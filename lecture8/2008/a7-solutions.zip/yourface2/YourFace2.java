package yourface2;

import yourface2.entities.Network;
import yourface2.entities.Person;
import yourface2.entities.Relationship;
import yourface2.entities.SocialEntity;

public class YourFace2 {

  public static void main(String[] args) {
    Person usman = new Person("Usman Akeju", 0, "Mount Vernon, NY");
    Person evan = new Person("Evan Jones", 1, "Canada");
    Person olivier = new Person("Olivier Koch", 2, "France");
    Person student1 = new Person("Sixho Neintu", 6, "Cambridge, MA");
    Person student2 = new Person("Stu Dent", 7, "Somerville, MA");
    
    usman.addAcquaintance(evan, Relationship.COWORKER);
    usman.addAcquaintance(olivier, Relationship.COWORKER);
    usman.addAcquaintance(student1, Relationship.STUDENT);
    
    evan.addAcquaintance(olivier, Relationship.COWORKER);
    evan.addAcquaintance(student2, Relationship.STUDENT);
    
    olivier.addAcquaintance(student1, Relationship.STUDENT);

    student1.addAcquaintance(usman, Relationship.TEACHER);
    student1.addAcquaintance(olivier, Relationship.TEACHER);
    student1.addAcquaintance(student2, Relationship.FRIEND);

    student2.addAcquaintance(evan, Relationship.TEACHER);

    
    // Example: 3 Networks
    Network mit = new Network("MIT", 3);
    Network canada = new Network("Canada", 4);
    Network france = new Network("France", 5);
    
    usman.addNetwork(mit);
    evan.addNetwork(mit);
    evan.addNetwork(canada);
    olivier.addNetwork(mit);
    olivier.addNetwork(france);
    student1.addNetwork(mit);
    student2.addNetwork(mit);

    // Example: Groups
    // ... you can do this ...
    
    // Example: Bands
    // ... you can do this ...
    
    printArray(new Person[]{usman, evan, olivier, student1, student2});
    
  }
  
  public static void printArray(SocialEntity[] array) {
    for (SocialEntity o : array) {
      System.out.println(o);
      System.out.println();
    }
  }

}

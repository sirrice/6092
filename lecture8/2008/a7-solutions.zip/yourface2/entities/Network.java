package yourface2.entities;

public class Network extends AbstractSocialGrouping {
  
  public Network(String name, long id) {
    super(name, id);
  }

  public String toString() {
    String memsToString = "\n Members: ";
    for (Person m : this.members) {
      memsToString += "\n  "+m.getName();
    }
    return "Group #"+getId()+": "+getName()+memsToString;
  }

}

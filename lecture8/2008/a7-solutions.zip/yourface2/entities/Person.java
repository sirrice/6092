package yourface2.entities;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Person extends AbstractSocialEntity {
  
  protected Map<Person,Relationship> acquaintances;
  protected Set<Network> networks;
  protected String location;
  
  public Person(String name, long id, String location) {
    super(name, id);
    this.location = location;
    this.acquaintances = new HashMap<Person, Relationship>();
    this.networks = new HashSet<Network>();
  }

  public Map<Person,Relationship> getAcquaintances() {
    return this.acquaintances;
  }
  
  public void addAcquaintance(Person p, Relationship r) {
    this.acquaintances.put(p, r);
    if (r.isMutual()) {
      p.getAcquaintances().put(this, r);
    }
  }
  
  public void addAcquaintance(Person p) {
    this.addAcquaintance(p, Relationship.ACQUAINTANCE);
  }

  public Relationship getRelationship(Person p) {
    return this.acquaintances.get(p);
  }

  public Set<Network> getNetworks() {
    return this.networks;
  }
  
  public void addNetwork(Network network) {
    this.networks.add(network);
  }
  
  public String getLocation() {
    return location;
  }
  
  public void setLocation(String location) {
    this.location = location;
  }
  
  public String toString() {
    String acqsToString = "\n Acquaintances: ";
    for (Person p : acquaintances.keySet()) {
      acqsToString += 
        "\n  "+p.getName()+" "+getRelationship(p)+" "+this.getName();
    }
    String netsToString = "\n Networks: ";
    for (Network n : networks) {
      netsToString += "\n  "+n.getName();
    }
    return "Person #"+getId()+": "+getName()+
            "\n Location: "+getLocation()+
            acqsToString+netsToString;
  }
  
}

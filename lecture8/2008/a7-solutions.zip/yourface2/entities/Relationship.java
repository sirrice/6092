package yourface2.entities;

public class Relationship {
  
  private final String type;
  private final String decsription;
  private final boolean isMutual;
  
  public static final Relationship
    ACQUAINTANCE = new Relationship("acquaintance", true),
    FRIEND = new Relationship("friend", true),
    COWORKER = new Relationship("coworker", true),
    RELATIVE = new Relationship("relative", true),
    STUDENT = new Relationship("student", false),
    TEACHER = new Relationship("teacher", false);
  
  public Relationship(String type, boolean isMutual, String description) {
    this.type = type;
    this.isMutual = isMutual;
    this.decsription = description;
  }

  public Relationship(String type, boolean isMutual) {
    this(type, isMutual, "is a "+ type + " of");
  }

  public String getType() {
    return this.type;
  }
  
  public boolean isMutual() {
    return this.isMutual;
  }

  public String getDescription() {
    return this.decsription;
  }
  
  public String toString() {
    return getDescription();
  }

}

package yourface2.entities;

public interface SocialEntity {
  
  public String getName();
  public long getId();

}

package yourface2.entities;

import java.util.HashSet;
import java.util.Set;

public class Band extends AbstractSocialEntity {
  
  protected final Set<Person> fans;
  protected String description;
  protected String location;
  
  public Band(String name, long id, String description, String location) {
    super(name, id);
    this.description = description;
    this.location = location;
    this.fans = new HashSet<Person>();
  }

  public Set<Person> getFans() {
    return this.fans;
  }
  
  public void addFan(Person fan) {
    this.fans.add(fan);
  }
  
  public String getDescription() {
    return description;
  }
  
  public void setDescription(String description) {
    this.description = description;
  }
  
  public String getLocation() {
    return location;
  }
  
  public void setLocation(String location) {
    this.location = location;
  }

  public String toString() {
    String fansToString = "\n Acquaintances: ";
    for (Person f : this.fans) {
      fansToString += "\n  "+f.getName();
    }
    return "Person #"+getId()+": "+getName()+
            "\n Description: "+getDescription()+
            "\n Location: "+getLocation()+
            fansToString;
  }
  
}

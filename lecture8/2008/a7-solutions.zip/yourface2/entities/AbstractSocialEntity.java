package yourface2.entities;

public abstract class AbstractSocialEntity implements SocialEntity {
  
  protected final String name;
  protected final long id;
  
  protected AbstractSocialEntity(String name, long id) {
    this.name = name;
    this.id = id;
  }
  
  public String getName() {
    return this.name;
  }

  public long getId() {
    return this.id;
  }

}

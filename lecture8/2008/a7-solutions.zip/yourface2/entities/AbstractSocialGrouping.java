package yourface2.entities;

import java.util.HashSet;
import java.util.Set;

public abstract class AbstractSocialGrouping extends AbstractSocialEntity {
  
  protected final Set<Person> members;
  
  protected AbstractSocialGrouping(String name, long id) {
    super(name, id);
    this.members = new HashSet<Person>();
  }
  
  public Set<Person> getMembers() {
    return this.members;
  }

  public void addMember(Person p) {
    this.members.add(p);
  }

}
